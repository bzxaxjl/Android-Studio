# TestChatdemo
a demo for Android chat look like Weixin 最简单快速的仿微信聊天demo

使用了开源的键盘控件 感谢
https://github.com/w446108264/XhsEmoticonsKeyboard

另外项目中附赠微信原生表情，qq原生表情，还有我自己下载的表情
表情下载地址
http://emojipedia.org/apple/
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/gif1.gif)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/gif2.gif)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/gif3.gif)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/gif4.gif)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/1.png)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/2.png)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/3.png)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/4.png)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/5.png)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/6.png)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/7.png)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/8.png)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/9.png)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/10.png)
###
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/11.png)
###

![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/12.png)
###
qq原生表情
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/13.png)
###
微信原生表情
![image](https://github.com/PangHaHa12138/TestChatdemo/blob/master/screenhot/14.png)
