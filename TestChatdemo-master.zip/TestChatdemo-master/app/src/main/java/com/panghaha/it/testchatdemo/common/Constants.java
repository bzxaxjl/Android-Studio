package com.panghaha.it.testchatdemo.common;

public class Constants {

    public static int EMOTICON_CLICK_TEXT = 1;
    public static int EMOTICON_CLICK_BIGIMAGE = 2;
}
