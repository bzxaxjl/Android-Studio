package com.panghaha.it.testchatdemo;

/**
 * Created by pang on 2017/4/12.
 */
public class Data_uploadBack_tag {

    /**
     * result : 1
     * failcode :
     */

    private String result;
    private String failcode;
    private String taskid;

    public String getTaskid() {
        return taskid;
    }

    public void setTaskid(String taskid) {
        this.taskid = taskid;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getFailcode() {
        return failcode;
    }

    public void setFailcode(String failcode) {
        this.failcode = failcode;
    }
}
