package com.panghaha.it.testchatdemo;

/***
 * ━━━━ Code is far away from ━━━━━━
 * 　　  () 　　　  ()
 * 　　  ( ) 　　　( )
 * 　　  ( ) 　　　( )
 * 　　┏┛┻━━━┛┻┓
 * 　　┃　　　━　　　┃
 * 　　┃　┳┛　┗┳　┃
 * 　　┃　　　┻　　　┃
 * 　　┗━┓　　　┏━┛
 * 　　　　┃　　　┃
 * 　　　　┃　　　┗━━━┓
 * 　　　　┃　　　　　　　┣┓
 * 　　　　┃　　　　　　　┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　　┃┫┫　┃┫┫
 * 　　　　　┗┻┛　┗┻┛
 * ━━━━ bug with the more protecting ━━━
 * <p/>
 * Created by PangHaHa12138 on 2017/6/7.
 *   网络请求接口
 */
public class Http_Api {
    //测试地址
    public static final String URL_SERVER = "http://123.56.97.229:6080/Server";
    //发送消息
    public static final String URL_NewSend = URL_SERVER + "/news/create.do";//post
    //接收消息
    public static final String URL_NewReceiver = URL_SERVER + "/news/selectNews.do";//get
}
