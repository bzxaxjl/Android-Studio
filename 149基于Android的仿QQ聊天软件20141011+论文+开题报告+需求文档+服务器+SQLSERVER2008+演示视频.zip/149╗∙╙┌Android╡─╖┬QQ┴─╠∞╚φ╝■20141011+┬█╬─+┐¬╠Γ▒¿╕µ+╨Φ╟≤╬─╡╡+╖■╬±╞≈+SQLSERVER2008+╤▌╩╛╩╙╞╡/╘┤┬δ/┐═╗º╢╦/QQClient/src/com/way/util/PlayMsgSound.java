package com.way.util;

public class PlayMsgSound {

}
